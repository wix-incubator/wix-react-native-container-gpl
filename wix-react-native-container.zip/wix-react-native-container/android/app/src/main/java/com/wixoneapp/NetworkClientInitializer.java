/*
 * This file is part of the Wix React Native Container.
 *
 * Copyright (C) 2016 Wix.com Ltd
 *
 * Wix React Native Container is free software: you can redistribute it
 * and/or modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 2 of the License.
 *
 * Wix React Native Container is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with Wix React Native Container.  If not, see <http://www.gnu.org/licenses/>.
 */
 package com.wixoneapp;

import android.os.Build;

import com.facebook.react.modules.network.OkHttpClientProvider;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class NetworkClientInitializer {
    public static void init() {
        OkHttpClient originalClient = OkHttpClientProvider.getOkHttpClient();

        OkHttpClient.Builder builder = originalClient.newBuilder();
        builder.addNetworkInterceptor(new UserAgentInterceptor(getWixUserAgent()));
        OkHttpClient newClient = builder.build();

        OkHttpClientProvider.replaceOkHttpClient(newClient);
    }

    private NetworkClientInitializer() {
    }

    private static String getWixUserAgent() {
        return getDefaultUserAgent() + " Wix/0";
    }

    private static String getDefaultUserAgent() {
            return "Android/" + Build.VERSION.SDK_INT;
    }

    private static class UserAgentInterceptor implements Interceptor {

        private final String userAgent;

        public UserAgentInterceptor(String userAgent) {
            this.userAgent = userAgent;
        }

        @Override
        public Response intercept(Chain chain) throws IOException {
            Request originalRequest = chain.request();
            Request requestWithUserAgent = originalRequest.newBuilder()
                    .removeHeader("User-Agent")
                    .header("User-Agent", userAgent)
                    .build();
            return chain.proceed(requestWithUserAgent);
        }
    }

}
