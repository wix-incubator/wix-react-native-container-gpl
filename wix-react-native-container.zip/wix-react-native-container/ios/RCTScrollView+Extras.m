/*
 * This file is part of the Wix React Native Container.
 * 
 * Copyright (C) 2016 Wix.com Ltd
 * 
 * Wix React Native Container is free software: you can redistribute it 
 * and/or modify it under the terms of the GNU General Public License as 
 * published by the Free Software Foundation, either version 2 of the License.
 * 
 * Wix React Native Container is distributed in the hope that it will be 
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General 
 * Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along 
 * with Wix React Native Container.  If not, see <http://www.gnu.org/licenses/>.
 */
#import "RCTScrollView+Extras.h"
#import "RCTUIManager.h"
#import "RCTScrollView.h"
#import <objc/runtime.h>


const char kDeallocWatcherKey;

@interface DeallocWatcher : NSObject
@property(nonatomic, weak) NSObject *refObj;
@property(nonatomic, weak) NSObject *observerRef;
@end

@implementation DeallocWatcher

- (void)dealloc
{
  if ([self.refObj isKindOfClass:[UIScrollView class]])
  {
    UIScrollView *scrollView = (UIScrollView*)self.refObj;
    [scrollView removeObserver:self.observerRef forKeyPath:@"contentSize"];
  }
}

@end


static __weak id currentFirstResponder;

@implementation UIResponder (FirstResponder)

+(id)currentFirstResponder {
  currentFirstResponder = nil;
  [[UIApplication sharedApplication] sendAction:@selector(findFirstResponder:) to:nil from:nil forEvent:nil];
  return currentFirstResponder;
}

-(void)findFirstResponder:(id)sender {
  currentFirstResponder = self;
}

@end


@implementation RCTScrollViewManager (Extras)

RCT_EXPORT_METHOD(activateScrollToCursorOnSizeChange:(nonnull NSNumber *)reactTag)
{
  [self.bridge.uiManager addUIBlock:
   ^(__unused RCTUIManager *uiManager, NSDictionary<NSNumber *, RCTScrollView *> *viewRegistry){
     RCTScrollView *view = viewRegistry[reactTag];
     if (view != nil && [view isKindOfClass:[RCTScrollView class]])
     {
       static dispatch_once_t onceToken;
       dispatch_once(&onceToken, ^
       {
         [view.scrollView addObserver:self forKeyPath:@"contentSize" options:NSKeyValueObservingOptionNew | NSKeyValueObservingOptionOld context:NULL];

                  DeallocWatcher *deallocWatcher = [DeallocWatcher new];
         deallocWatcher.refObj = view.scrollView;
         deallocWatcher.observerRef = self;
         objc_setAssociatedObject(view, &kDeallocWatcherKey, deallocWatcher, OBJC_ASSOCIATION_RETAIN);
       });
     }
   }];
}

- (void) observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
  if ([keyPath isEqualToString:@"contentSize"] && [object isKindOfClass:[UIScrollView class]])
  {
    UIScrollView *scrollView = (UIScrollView*)object;
    id firstResponder = [UIResponder currentFirstResponder];
    if ([firstResponder isKindOfClass:[UITextView class]] && [firstResponder isDescendantOfView:scrollView])
    {
      UITextView *textView = (UITextView*)firstResponder;
      CGRect caretRect = [textView caretRectForPosition:textView.selectedTextRange.start];
      caretRect = [scrollView convertRect:caretRect fromView:textView];
      if (caretRect.origin.y + caretRect.size.height > scrollView.frame.size.height + scrollView.contentOffset.y - scrollView.contentInset.top  )
      {
        [scrollView setContentOffset:CGPointMake(scrollView.contentOffset.x, caretRect.origin.y - scrollView.frame.size.height + caretRect.size.height + 2) animated:YES];
      }
      else if(caretRect.origin.y < scrollView.contentOffset.y)
      {
        [scrollView setContentOffset:CGPointMake(scrollView.contentOffset.x, caretRect.origin.y - 2) animated:YES];
      }
    }
  }
}

@end
